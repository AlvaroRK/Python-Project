from setuptools import setup

setup(
    name="2daPre-entrega",
    version="1.0",
    description="Este paquete incluye tanto la primera pre-entrega como la segunda",
    author="Alvaro Ruiz Kuschill",
    packages=["paquete_1"]
)